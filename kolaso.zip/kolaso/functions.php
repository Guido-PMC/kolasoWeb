<?php
/**
 * kolaso functions and definitions.
 *
 * @package kolaso
 */
 require_once get_template_directory() . '/framework/init.php';
